/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es.uja.ssccdd.curso2122.sesion3;

import static es.uja.ssccdd.curso2122.sesion3.Constantes.ASIGNADO;
import static es.uja.ssccdd.curso2122.sesion3.Constantes.FIN_EJECUCION;
import static es.uja.ssccdd.curso2122.sesion3.Constantes.MAX_ORDENADORES;
import static es.uja.ssccdd.curso2122.sesion3.Constantes.MIN_ORDENADORES;
import static es.uja.ssccdd.curso2122.sesion3.Constantes.MIN_TIEMPO_PROCESADO;
import static es.uja.ssccdd.curso2122.sesion3.Constantes.PRIMERO;
import es.uja.ssccdd.curso2122.sesion3.Constantes.TipoComponente;
import static es.uja.ssccdd.curso2122.sesion3.Constantes.VARIACION_TIEMPO_PROCESADO;
import static es.uja.ssccdd.curso2122.sesion3.Constantes.aleatorio;
import static es.uja.ssccdd.curso2122.sesion3.Constantes.componentes;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Optional;
import java.util.concurrent.Phaser;
import java.util.concurrent.TimeUnit;

/**
 *
 * @author pedroj
 */
public class Proveedor implements Runnable {

    private final String iD;
    private final ArrayList<Componente> listaComponentes;
    private final ArrayList<Ordenador> resultadoEjecucion;
    private int numIntentos;
    private final Phaser sincronizacion;

    private ArrayList<TipoComponente> componentesFaltantes;

    public Proveedor(String iD, ArrayList<Componente> listaComponentes, ArrayList<Ordenador> resultadoEjecucion, Phaser sincronizacion) {
        this.iD = iD;
        this.listaComponentes = listaComponentes;
        this.resultadoEjecucion = resultadoEjecucion;
        this.sincronizacion = sincronizacion;
        componentesFaltantes = new ArrayList();
        this.numIntentos = 0;
    }

    @Override
    public void run() {
        boolean finEjecucion;

        System.out.println("El HILO(" + iD + ") comienza su ejecución");
        finEjecucion = !FIN_EJECUCION;
        int MIN_INTENTOS = resultadoEjecucion.size() / 80 * 100;
        int numOrdenadores = MIN_ORDENADORES + aleatorio.nextInt(MAX_ORDENADORES - MIN_ORDENADORES);
        for (int i = 0; i < numOrdenadores; i++) {
            nuevoOrdenador();
        }
        int tiposComponente = componentes.length;
        Thread[] hilos;
        hilos = new Thread[tiposComponente];

        try {
            //do {
            for (Ordenador ord : resultadoEjecucion) {
                sincronizacion.wait();
                if (!finEjecucion) {

                    componentesFaltantes = ord.componenteFaltante();
                    for (int i = 0; i < componentesFaltantes.size(); i++) {
                        Fabricante fab = new Fabricante(iD, componentesFaltantes.get(i), listaComponentes, sincronizacion);
                        hilos[i] = new Thread(fab, fab.getId());
                        hilos[i].start();
                    }

                    if (ord.isCompleto()) {
                        numIntentos++;
                        if (numIntentos > MIN_INTENTOS) {
                            finEjecucion = FIN_EJECUCION;
                        }
                    }

//                    for (Componente com : listaComponentes) {
//                        int i=0;
//                        if (com != null && com.getTipo()==componentesFaltantes.get(i)) {
//                            // Comprobamos que tenemos un componente
//                            
//                        } else {
//                            numIntentos++;
//                            if (numIntentos > MIN_INTENTOS) {
//                                finEjecucion = FIN_EJECUCION;
//                            }
//                        }
//                        i++;
//                    }
                }
            }
            //}while (!finEjecucion);

            System.out.println("El HILO(" + iD + ") ha finalizado su ejecución");
        } catch (InterruptedException ex) {
            System.out.println("El HILO(" + iD + ") ha sido INTERRUMPIDO");
        }

    }

    public String getiD() {
        return iD;
    }

    /**
     * Optiene un componente si está presente en la lista de componentes
     * compartida entre los proveedores. Solo se permite la interrupción si no
     * hemos obrenido un componente.
     *
     * @return el componente si se encuentra presente en la lista
     * @throws InterruptedException
     */
    private Optional<Componente> obtenerComponente() throws InterruptedException {
        Optional<Componente> componente;
        int tiempo;

        // Simulamos el tiempo de operación
        tiempo = MIN_TIEMPO_PROCESADO + aleatorio.nextInt(VARIACION_TIEMPO_PROCESADO);
        TimeUnit.SECONDS.sleep(tiempo);

        try {
            componente = Optional.ofNullable(listaComponentes.remove(PRIMERO));
        } catch (IndexOutOfBoundsException ex) {
            // No hay componente
            componente = Optional.empty();
        }

        return componente;
    }

    /**
     * Asigna un componente a la lista de ordenadores disponibles si es posible
     *
     * @param componente
     * @return Si se ha podido añadir el componente a un ordenador
     */
    private boolean asignarComponente(Componente componente) {
        boolean asignado = !ASIGNADO;
        Iterator it;

        // Asignamos el componente al primer ordenador posible
        it = resultadoEjecucion.iterator();
        while (it.hasNext() && !asignado) {
            Ordenador ordenador = (Ordenador) it.next();
            if (ordenador.addComponente(componente)) {
                asignado = ASIGNADO;
            }
        }

        return asignado;
    }

    /**
     * Crea un nuevo ordenador donde añadir el componente
     *
     * @param componente
     */
    private void nuevoOrdenador() {
        Ordenador ordenador;

        ordenador = new Ordenador("Ordenador-" + resultadoEjecucion.size());
        resultadoEjecucion.add(ordenador);

        System.out.println("El HILO(" + iD + ") ha creado un ordenador para ");
    }
}

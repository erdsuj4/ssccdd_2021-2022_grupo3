/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es.uja.ssccdd.curso2122.sesion3;

import static es.uja.ssccdd.curso2122.sesion3.Constantes.MAX_PROVEEDORES;
import static es.uja.ssccdd.curso2122.sesion3.Constantes.MIN_PROVEEDORES;
import static es.uja.ssccdd.curso2122.sesion3.Constantes.aleatorio;
import java.util.ArrayList;
import java.util.concurrent.Phaser;

/**
 *
 * @author UJA
 */
public class Sesion3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ArrayList<Componente> arrayComponentes;
        ArrayList<Ordenador> arrayordenadores;
        Phaser sincronizar;
        Thread[] hilos;
        int numProv;
         numProv=MIN_PROVEEDORES+aleatorio.nextInt(MAX_PROVEEDORES-MIN_PROVEEDORES);
        arrayComponentes=new ArrayList();
        arrayordenadores=new ArrayList();
        sincronizar=new Phaser(numProv);
        hilos=new Thread[numProv];
       
        for (int i = 0; i < numProv; i++) {
            Proveedor prov=new Proveedor(String.valueOf(i), arrayComponentes, arrayordenadores, sincronizar);
            hilos[i]=new Thread(prov,prov.getiD());
            hilos[i].start();
        }
        
        if(sincronizar.getArrivedParties()==(30*numProv/100)){
            for (Thread hilo : hilos) {
                hilo.interrupt();
            }
        }
        
        for (Ordenador ord : arrayordenadores) {
            System.out.println(ord);
        }
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es.uja.ssccdd.curso2122.sesion3;

import static es.uja.ssccdd.curso2122.sesion3.Constantes.MAX_COMPONENTES;
import static es.uja.ssccdd.curso2122.sesion3.Constantes.MIN_COMPONENTES;
import static es.uja.ssccdd.curso2122.sesion3.Constantes.MIN_TIEMPO_PROCESADO;
import es.uja.ssccdd.curso2122.sesion3.Constantes.TipoComponente;
import static es.uja.ssccdd.curso2122.sesion3.Constantes.VARIACION_TIEMPO_PROCESADO;
import static es.uja.ssccdd.curso2122.sesion3.Constantes.aleatorio;
import java.util.ArrayList;
import java.util.concurrent.Phaser;
import java.util.concurrent.TimeUnit;

/**
 *
 * @author pedroj
 */
public class Fabricante implements Runnable {

    private final String id;
    private TipoComponente tipo;
    ArrayList componentes;
    Phaser sincronizador;

    public Fabricante(String id, TipoComponente tipo, ArrayList componentes, Phaser sincronizador) {
        this.id = id;
        this.tipo = tipo;
        this.componentes = componentes;
        this.sincronizador = sincronizador;
    }

    public String getId() {
        return id;
    }

    void crearComponentes() throws InterruptedException {
        if (Thread.currentThread().isInterrupted()) {
            throw new InterruptedException();
        }

        int componentesCreados =MIN_COMPONENTES+aleatorio.nextInt(MAX_COMPONENTES - MIN_COMPONENTES);

        for (int i = 0; i < componentesCreados; i++) {
            Componente comp = new Componente(String.valueOf(i), this.tipo);
            int timeCreacion = MIN_TIEMPO_PROCESADO+aleatorio.nextInt(VARIACION_TIEMPO_PROCESADO - MIN_TIEMPO_PROCESADO + 1);
            TimeUnit.SECONDS.sleep(timeCreacion);
            componentes.add(comp);
        }
    }

    @Override
    public void run() {
        try {
            sincronizador.awaitAdvanceInterruptibly(sincronizador.arrive());
            crearComponentes();
        } catch (InterruptedException ex) {
            System.out.println("Ha ocurrido una interrupción en el fabricante " + this.id);
        } finally {

            sincronizador.arriveAndDeregister();
        }
    }

}

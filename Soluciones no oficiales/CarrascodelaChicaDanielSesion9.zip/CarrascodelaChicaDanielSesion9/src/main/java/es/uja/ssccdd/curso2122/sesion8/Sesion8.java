/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es.uja.ssccdd.curso2122.sesion8;

import static es.uja.ssccdd.curso2122.sesion8.Constantes.MAX_FABRICANTE;
import static es.uja.ssccdd.curso2122.sesion8.Constantes.MAX_ORDENADORES;
import static es.uja.ssccdd.curso2122.sesion8.Constantes.MAX_PROVEEDORES;
import static es.uja.ssccdd.curso2122.sesion8.Constantes.MIN_FABRICANTE;
import static es.uja.ssccdd.curso2122.sesion8.Constantes.MIN_ORDENADORES;
import static es.uja.ssccdd.curso2122.sesion8.Constantes.MIN_PROVEEDORES;
import static es.uja.ssccdd.curso2122.sesion8.Constantes.TIEMPO_ESPERA;
import static es.uja.ssccdd.curso2122.sesion8.Constantes.TIEMPO_ESPERA_2;
import static es.uja.ssccdd.curso2122.sesion8.Constantes.aleatorio;
import static es.uja.ssccdd.curso2122.sesion8.Constantes.componentes;
import java.util.ArrayList;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicIntegerArray;

/**
 *
 * @author UJA
 */
public class Sesion8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws InterruptedException, ExecutionException {
        // TODO code application logic here
        ExecutorService ejecucion;
        AtomicIntegerArray componentesDisponibles;
        Proveedor proveedor;
        Fabricante fabricante;
        Resultado resultado;
        
        ArrayList<Proveedor> arrayProveedor=new ArrayList();

        int numProveedor=MIN_PROVEEDORES+aleatorio.nextInt(MAX_PROVEEDORES-MIN_PROVEEDORES);
        int numFabricante=MIN_FABRICANTE+aleatorio.nextInt(MAX_FABRICANTE-MIN_FABRICANTE);
        
        ejecucion = Executors.newCachedThreadPool();
        int numOrdenadores;
        
        componentesDisponibles=new AtomicIntegerArray(componentes.length);
        for(int i=0;i<numProveedor;i++){
            numOrdenadores=MIN_ORDENADORES+aleatorio.nextInt(MAX_ORDENADORES-MIN_ORDENADORES);
            proveedor=new Proveedor("Prov "+i, componentesDisponibles, numOrdenadores);
            arrayProveedor.add(proveedor);
        }
        
        for(int i=0;i<numFabricante;i++){
            fabricante=new Fabricante("Fab "+i, componentesDisponibles);
            ejecucion.execute(fabricante);
        }
        
        resultado=ejecucion.invokeAny(arrayProveedor);
        
        System.out.println("(HILO_PRINCIPAL) Espera a por un tiempo a que los clientes realicen compras");
       
        
        // Se solicita la cancelación de las tareas que no han finalizado
        System.out.println("(HILO_PRINCIPAL) Solicita la finalización");
        ejecucion.shutdownNow();
        ejecucion.awaitTermination(TIEMPO_ESPERA, TimeUnit.DAYS);
        
        System.out.println(resultado);
        
        System.out.println("Ha finalizado la ejecución el Hilo(PRINCIPAL)");

    }
    
}

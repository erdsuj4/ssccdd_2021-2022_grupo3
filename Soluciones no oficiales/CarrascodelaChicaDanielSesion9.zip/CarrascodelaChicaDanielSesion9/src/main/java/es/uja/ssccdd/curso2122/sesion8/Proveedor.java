/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es.uja.ssccdd.curso2122.sesion8;

import static es.uja.ssccdd.curso2122.sesion8.Constantes.ASIGNADO;
import static es.uja.ssccdd.curso2122.sesion8.Constantes.FABRICACION_NECESARIA;
import static es.uja.ssccdd.curso2122.sesion8.Constantes.FINAL_PEDIDO;
import static es.uja.ssccdd.curso2122.sesion8.Constantes.MIN_ORDENADORES;
import static es.uja.ssccdd.curso2122.sesion8.Constantes.MAX_ORDENADORES;
import static es.uja.ssccdd.curso2122.sesion8.Constantes.MIN_TIEMPO_PROCESADO;
import static es.uja.ssccdd.curso2122.sesion8.Constantes.OBJETIVO_CONSTRUCCION;
import es.uja.ssccdd.curso2122.sesion8.Constantes.TipoComponente;
import static es.uja.ssccdd.curso2122.sesion8.Constantes.TipoComponente.getTipoComponente;
import static es.uja.ssccdd.curso2122.sesion8.Constantes.VARIACION_TIEMPO_PROCESADO;
import static es.uja.ssccdd.curso2122.sesion8.Constantes.aleatorio;
import static es.uja.ssccdd.curso2122.sesion8.Constantes.componentes;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicIntegerArray;

/**
 *
 * @author pedroj
 */
public class Proveedor implements Callable<Resultado> {

    private final String iD;
    private AtomicIntegerArray ordenadoresCreados;
    private List<Ordenador> listaOrdenadores;
    private AtomicIntegerArray componentesDisponibles;
    private List<Componente> componentesNoAsignados;

    private final boolean[] fabricacionPendiente;
    private int ordenadoresCompletados;
    private int numOrdenadores;
    

    public Proveedor(String iD, AtomicIntegerArray componentesDisponibles, int numOrdenadores) {
        this.iD = iD;
        this.componentesNoAsignados = new ArrayList();
        this.listaOrdenadores = new ArrayList();
        this.ordenadoresCompletados = 0;
        this.ordenadoresCreados = new AtomicIntegerArray(numOrdenadores);
        this.componentesDisponibles = componentesDisponibles;
        // Genera los ordenadores 
        this.numOrdenadores = MIN_ORDENADORES + aleatorio.nextInt(MAX_ORDENADORES - MIN_ORDENADORES);
        this.ordenadoresCompletados = (numOrdenadores * OBJETIVO_CONSTRUCCION) / 100;

        // Componentes pendientes de fabricación
        this.fabricacionPendiente = new boolean[componentes.length];
        for (int i = 0; i < componentes.length; i++) {
            fabricacionPendiente[i] = FABRICACION_NECESARIA;
        }

    }
    
    

    @Override
    public Resultado call() throws Exception {
        Resultado resultado = null;

        System.out.println("LA TAREA(" + iD + ") comienza la preparación de "
                + ordenadoresCompletados + " ordenadores completos");

        try {
            crearOrdenadores();

            // Hasta su finalización o su interrupción
            while (ordenadoresCompletados != FINAL_PEDIDO) {
                System.out.println("LA TAREA(" + iD + ") espera nuevos componentes");
                nuevosComponentes();
            }

            resultado = new Resultado("Resultado-" + iD, listaOrdenadores, componentesNoAsignados);
            System.out.println("LA TAREA(" + iD + ") ha FINALIZADO");
        } catch (InterruptedException ex) {
            System.out.println("LA TAREA(" + iD + ") ha sido INTERRUMPIDO");
        }

        return resultado;
    }

    public String getiD() {
        return iD;
    }

    private void crearOrdenadores() throws InterruptedException {
        if (Thread.interrupted()) {
            throw new InterruptedException();
        }
        for (int i = 0; i < numOrdenadores; i++) {
            Ordenador ordenador = new Ordenador(iD + "-Ordenador-" + i);
            listaOrdenadores.add(ordenador);
            ordenadoresCreados.getAndDecrement(i);
        }
    }

    private void nuevosComponentes() throws InterruptedException {
        if (Thread.interrupted()) {
            throw new InterruptedException();
        }

        for (int i = 0; i < componentesDisponibles.length(); i++) {
            if (componentesDisponibles.decrementAndGet(i) > 0) {
                TipoComponente tipo = componentes[i];
                boolean asignado = !ASIGNADO;
                int indice = 0;
                int tiempo;
                Componente c=new Componente(iD, tipo);
                // Asignamos el componente al primer ordenador posible
                while ((indice < listaOrdenadores.size()) && !asignado) {
                    Ordenador ordenador = listaOrdenadores.get(indice);
                    
                    if (ordenador.addComponente(c)) {
                        asignado = ASIGNADO;
                        if (ordenador.isCompleto()) // Uno menos para finalizar el trabajo
                        {
                            ordenadoresCompletados--;
                        }

                        System.out.println("LA TAREA(" + iD + ") ha asignado " + c
                                + " al ordenador " + ordenador.getID()
                                + " ordenadores pendientes " + ordenadoresCompletados);
                    }

                    indice++;

                    // Simulamos el tiempo de operación
                    tiempo = MIN_TIEMPO_PROCESADO + aleatorio.nextInt(VARIACION_TIEMPO_PROCESADO);
                    TimeUnit.SECONDS.sleep(tiempo);
                }

                // No se necesita más ese componente
                if (!asignado) {
                    fabricacionPendiente[tipo.ordinal()] = !FABRICACION_NECESARIA;
                    componentesNoAsignados.add(c);
                }

            }
        }
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es.uja.ssccdd.curso2122.sesion8;

import es.uja.ssccdd.curso2122.sesion8.Constantes.TipoComponente;
import static es.uja.ssccdd.curso2122.sesion8.Constantes.TipoComponente.getTipoComponente;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicIntegerArray;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author pedroj
 */
public class Fabricante implements Runnable,Constantes {

    public Fabricante(String nombre, AtomicIntegerArray componentesDisponibles) {
        this.nombre = nombre;
        this.componentesDisponibles = componentesDisponibles;
    }
    
    private String nombre;
    private AtomicIntegerArray componentesDisponibles;
    @Override
    public void run() {
        try {
            ejecucion();
        } catch (InterruptedException ex) {
            Logger.getLogger(Fabricante.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void ejecucion() throws InterruptedException{
        if(Thread.interrupted()){
            throw new InterruptedException();
        }
        
        TipoComponente tipo=getTipoComponente();
        int tipocomp=tipo.ordinal();
        TimeUnit.SECONDS.sleep(TIEMPO_MIN+aleatorio.nextInt(TIEMPO_MAX-TIEMPO_MIN));
        int posicion=0;
        boolean encontrado=false;
        while(posicion<componentesDisponibles.length() && !encontrado){
            if(posicion==tipocomp){
                componentesDisponibles.getAndIncrement(posicion);
                encontrado=true;
            }
            posicion++;
        }
        
        TimeUnit.SECONDS.sleep(TIEMPO_ESPERA);
    }
    
    

    
}

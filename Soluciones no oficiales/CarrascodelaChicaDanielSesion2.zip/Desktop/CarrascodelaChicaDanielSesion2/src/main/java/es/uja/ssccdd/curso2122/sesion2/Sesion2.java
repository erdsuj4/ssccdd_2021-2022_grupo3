/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es.uja.ssccdd.curso2122.sesion2;

import static es.uja.ssccdd.curso2122.sesion2.Constantes.MAX_COMPONENTES;
import static es.uja.ssccdd.curso2122.sesion2.Constantes.MIN_COMPONENTES;
import static es.uja.ssccdd.curso2122.sesion2.Constantes.NUM_PROVEEDOR;
import static es.uja.ssccdd.curso2122.sesion2.Constantes.TIEMPO_MAX;
import static es.uja.ssccdd.curso2122.sesion2.Constantes.TIEMPO_MIN;
import static es.uja.ssccdd.curso2122.sesion2.Constantes.TipoComponente.getTipoComponente;
import static es.uja.ssccdd.curso2122.sesion2.Constantes.aleatorio;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;
import sun.awt.windows.ThemeReader;

/**
 *
 * @author UJA
 */
public class Sesion2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws InterruptedException {
        // TODO code application logic here
        String nombre;
        int id;
        Thread[] hilos;
        ArrayList<Componente>[] componentes;
        ArrayList<Ordenador>[] ordenadores;
        ArrayList<Ordenador>[] ordenadoresCompletados;
        Proveedor proveedor;
        int numComponentes;
        
        System.out.println("INICIANDO EJECUCION HILO PRINCIPAL");
        nombre="id ";
        id=0;
        componentes=new ArrayList[NUM_PROVEEDOR];
        ordenadores=new ArrayList[NUM_PROVEEDOR];
        ordenadoresCompletados=new ArrayList[NUM_PROVEEDOR];
        hilos=new Thread[NUM_PROVEEDOR];
        
        for(int i=0;i<NUM_PROVEEDOR;i++){
            componentes[i]=new ArrayList();
            ordenadores[i]=new ArrayList();
            ordenadoresCompletados[i]=new ArrayList();
            numComponentes=MIN_COMPONENTES+aleatorio.nextInt(MAX_COMPONENTES-MIN_COMPONENTES);
            for (int j = 0; j < numComponentes; j++) {
                componentes[i].add(new Componente(nombre+id, getTipoComponente()));
                id++;
                
                //TimeUnit.SECONDS.sleep(TIEMPO_MIN+aleatorio.nextInt(TIEMPO_MAX-TIEMPO_MIN));
                //System.out.println(numComponentes);
                //TimeUnit.SECONDS.sleep(1);
            }
            
            ordenadores[i]=new ArrayList();
            
            proveedor=new Proveedor(nombre+id, componentes[i], ordenadores[i], ordenadoresCompletados[i]);
            id++;
            hilos[i]=new Thread(proveedor);
        }
        
        for(Thread hilo : hilos){
            hilo.start();
        }
        
        TimeUnit.SECONDS.sleep(1);
        System.out.println("ESPERANDO A LA INTERRUPCION");
        for(Thread hilo : hilos){
            hilo.interrupt();
        }
        
        System.out.println("ESPERANDO A LA FINALIZACION");
        for(Thread hilo : hilos){
            hilo.join();
        }
        
    }
    
}

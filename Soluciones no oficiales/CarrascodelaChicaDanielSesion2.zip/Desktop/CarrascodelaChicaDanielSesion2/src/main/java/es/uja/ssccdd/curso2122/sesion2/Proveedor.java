/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es.uja.ssccdd.curso2122.sesion2;

import static es.uja.ssccdd.curso2122.sesion2.Constantes.ESPERA_MAX;
import static es.uja.ssccdd.curso2122.sesion2.Constantes.ESPERA_MIN;
import static es.uja.ssccdd.curso2122.sesion2.Constantes.NUM_INTENTOS;
import static es.uja.ssccdd.curso2122.sesion2.Constantes.aleatorio;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

/**
 *
 * @author pedroj
 */
public class Proveedor implements Runnable {

    public Proveedor(String nombre, ArrayList<Componente> componentes,ArrayList<Ordenador> ordenadores, ArrayList<Ordenador> ordenadoresCompletados) {
        this.nombre = nombre;
        this.componentes=componentes;
        this.ordenadores = ordenadores;
        this.ordenadoresCompletados = ordenadoresCompletados;
        this.procesados = 0;
        this.intentos = 0;
    }
    private final String nombre;
    private Componente componente;
    private ArrayList<Componente> componentes;
    private ArrayList<Ordenador> ordenadores;
    private ArrayList<Ordenador> ordenadoresCompletados;
    private int procesados;
    private int intentos;

    @Override
    public void run() {
        System.out.println(Thread.currentThread().getName() + " COMIENZA EJECUCION");
        try {
            ejecutar();
            System.out.println("FINALIZADO " + Thread.currentThread().getName());
        } catch (InterruptedException ex) {
            System.out.println("INTERRUMPIDO " + Thread.currentThread().getName());
        } finally {
            finalizar();
        }
    }

    private void ejecutar() throws InterruptedException {

        for (Componente componente : componentes) {
            if (intentos < NUM_INTENTOS) {
                if (componente == null) {
                    intentos++;
                } else {
                    if (Thread.interrupted()) {
                        throw new InterruptedException();
                    }
                    boolean salir = false;
                    for (Ordenador ord : ordenadores) {
                        if (!salir) {
                            if (ord.addComponente(componente)) {
                                salir = true;
                                componentes.remove(componente);
                            }
                        }
                    }

                    if (!salir) {
                        String nuevoNom = nombre + " " + procesados;
                        ordenadores.add(new Ordenador(nuevoNom));
                        ordenadores.get(ordenadores.size() - 1).addComponente(componente);
                        componentes.remove(componente);
                    }
                    try{
                    //TimeUnit.SECONDS.sleep(1);
                        TimeUnit.SECONDS.sleep(ESPERA_MIN + aleatorio.nextInt(ESPERA_MAX - ESPERA_MIN));
                    }catch(InterruptedException ex){
                        throw new InterruptedException();
                    }
                        procesados++;

                }
            }
        }

    }

    private void finalizar() {
        for (Ordenador ord : ordenadores) {
            if (ord.isCompleto()) {
                ordenadoresCompletados.add(ord);
            }
        }
    }
}

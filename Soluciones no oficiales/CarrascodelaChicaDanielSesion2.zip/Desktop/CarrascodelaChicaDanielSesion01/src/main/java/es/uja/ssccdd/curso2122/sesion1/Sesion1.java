/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es.uja.ssccdd.curso2122.sesion1;

import static es.uja.ssccdd.curso2122.sesion1.Constantes.D100;
import static es.uja.ssccdd.curso2122.sesion1.Constantes.LLENO;
import static es.uja.ssccdd.curso2122.sesion1.Constantes.MAXIMO;
import static es.uja.ssccdd.curso2122.sesion1.Constantes.MINIMO;
import static es.uja.ssccdd.curso2122.sesion1.Constantes.NUM_ORDENADORES;
import static es.uja.ssccdd.curso2122.sesion1.Constantes.TIPO_COMPONENTES;
import es.uja.ssccdd.curso2122.sesion1.Constantes.TipoComponente;
import static es.uja.ssccdd.curso2122.sesion1.Constantes.TipoComponente.getTipoComponente;
import static es.uja.ssccdd.curso2122.sesion1.Constantes.aleatorio;
import static es.uja.ssccdd.curso2122.sesion1.Constantes.componentes;
import java.util.ArrayList;

/**
 *
 * @author pedroj
 */
public class Sesion1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("EJECUCION HILO PRINCIPAL");
        int numComponentes;
        numComponentes=5000+MINIMO+aleatorio.nextInt(MAXIMO-MINIMO);
        int capacidad[];
        
        capacidad=new int[TIPO_COMPONENTES];
        for(int i=0;i<TIPO_COMPONENTES;i++){//asigno las capacidades para cada fila de la matriz de componentes
            capacidad[i]=componentes[i].getMinimoComponente();
        }
        
        ArrayList<Ordenador> arrayOrdenadores;
        arrayOrdenadores=new ArrayList<>(NUM_ORDENADORES);
        
        for(int i=0;i<NUM_ORDENADORES;i++){
            int ale=aleatorio.nextInt(D100);
            boolean nosimple=false;
            if(ale<50){
                nosimple=true;
            }else{
                nosimple=false;
            }
            arrayOrdenadores.add(new Ordenador(i, capacidad, nosimple));
        }
        
        ArrayList<Componente> arrayComponentes;
        ArrayList<Componente> arrayDescartados;
        arrayComponentes=new ArrayList<>(numComponentes);
        arrayDescartados=new ArrayList<>();
        
        for(int i=0;i<numComponentes;i++){
            TipoComponente tipo=getTipoComponente();
            Componente comp=new Componente(i, tipo);
            boolean asignado=false;
            for(int j=0;j<arrayOrdenadores.size() && !asignado;j++){
                if(arrayOrdenadores.get(j).addComponente(comp)!=LLENO){
                    asignado=true;
                    arrayComponentes.add(comp);
                }
            }
            if(!asignado){
                arrayDescartados.add(comp);
            }
        }
        
        
        System.out.println("LISTA DE ORDENADIRES");
        
        for(int i=0;i<arrayOrdenadores.size();i++){
            System.out.println(arrayOrdenadores.get(i));
        }
        System.out.println("\n");
        System.out.println("COMPONENTES AÑADIDOS");
        for(int i=0;i<arrayComponentes.size();i++){
            System.out.println(arrayComponentes.get(i));
        }
        System.out.println("\n");
        System.out.println("COMPONENTES NO AÑADIDOS");
        for(int i=0;i<arrayDescartados.size();i++){
            System.out.println(arrayDescartados.get(i));
        }
        System.out.println("FINALIZADO");
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es.uja.ssccdd.curso2122.sesion4;

import static es.uja.ssccdd.curso2122.sesion4.Constantes.MAX_ORDENADORES;
import static es.uja.ssccdd.curso2122.sesion4.Constantes.MIN_ORDENADORES;
import static es.uja.ssccdd.curso2122.sesion4.Constantes.TIEMPO_MIN;
import static es.uja.ssccdd.curso2122.sesion4.Constantes.TIEMPO_MAX;
import static es.uja.ssccdd.curso2122.sesion4.Constantes.aleatorio;
import static es.uja.ssccdd.curso2122.sesion4.Constantes.componentes;
import static es.uja.ssccdd.curso2122.sesion4.Sesion4.generaId;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

/**
 *
 * @author pedroj
 */
public class Proveedor implements Callable<Resultado> {

    public Proveedor(String nombre) {
        this.nombre = nombre;
        this.arrayOrdenadores = new ArrayList();
        this.ejecucion = Executors.newCachedThreadPool();
    }
    private String nombre;
    int numOrdenadores;

    ArrayList<Ordenador> arrayOrdenadores;
    List<Future<List<Componente>>> listaComponentes;
    ExecutorService ejecucion;

    @Override
    public Resultado call() throws Exception {
        Resultado res = null;
        inicializar();
        int i = 0;
        try {
            for (Ordenador orde : arrayOrdenadores) {
                asignacion(orde, i);
                i++;
            }
        } catch (InterruptedException ex) {
            System.out.println("Proveedor " + nombre + " cancelado");
        }finally{
            ejecucion.shutdownNow();
            ejecucion.awaitTermination(1, TimeUnit.DAYS);
        }
        return res;
    }

    private void inicializar() {
        int numOrdenadores = MIN_ORDENADORES + aleatorio.nextInt(MAX_ORDENADORES - MIN_ORDENADORES);
        for (int i = 0; i < numOrdenadores; i++) {
            arrayOrdenadores.add(new Ordenador(generaId()));
        }
    }

    private void asignacion(Ordenador o, int n) throws InterruptedException, ExecutionException {
        List<Fabricante> arrayFabricantes;
        arrayFabricantes = new LinkedList();
        if (!arrayOrdenadores.get(n).isCompleto()) {

            for (int i = 0; i < componentes.length; i++) {

                int numcomp = arrayOrdenadores.get(n).getComponentesOrdenador().size();
                ArrayList<Componente[]> c = arrayOrdenadores.get(n).getComponentesOrdenador();
                Componente[] componentesFabricante = c.get(i);

                int numComponentesDeUnTipo = 0;
                for (int j = 0; j < numcomp; j++) {
                    if (componentesFabricante[j].getTipo() == componentes[i]) {
                        numComponentesDeUnTipo++;
                    }
                }

                if (numComponentesDeUnTipo < componentes[i].getMinimoComponente()) {
                    arrayFabricantes.add(new Fabricante(generaId(), componentes[i]));
                }

            }
        }

        listaComponentes = ejecucion.invokeAll(arrayFabricantes);
        //espero hasta que todos los fabricantes terminen
        System.out.println("PROVEEDOR "+nombre+" MONTANDO EL ORDENADOR "+o);
        
        for (Future<List<Componente>> listaComponente : listaComponentes) {
            for(int z=0;z<listaComponente.get().size();z++){
                Componente comp=listaComponente.get().get(z);
                o.addComponente(comp);
                listaComponentes.remove(comp);
                int tiempospera=TIEMPO_MIN+aleatorio.nextInt(TIEMPO_MAX-TIEMPO_MIN);
                TimeUnit.SECONDS.sleep(tiempospera);
            }
            
        }
        
        TimeUnit.SECONDS.sleep(n);
    }

}

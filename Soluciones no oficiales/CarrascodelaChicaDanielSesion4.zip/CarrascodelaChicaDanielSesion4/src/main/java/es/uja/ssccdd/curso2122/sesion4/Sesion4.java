/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es.uja.ssccdd.curso2122.sesion4;

import static es.uja.ssccdd.curso2122.sesion4.Constantes.MAX_PROVEEDORES;
import static es.uja.ssccdd.curso2122.sesion4.Constantes.MIN_PROVEEEDORES;
import static es.uja.ssccdd.curso2122.sesion4.Constantes.aleatorio;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 *
 * @author UJA
 */
public class Sesion4 {
    static String ID="0";
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ExecutorService ejecucion;
        ArrayList<Proveedor> arrayProveedores;
        
        arrayProveedores=new ArrayList();
        
        System.out.println("EJECUCION HILO PRINCIPAL");
        
        int numProv=MIN_PROVEEEDORES+aleatorio.nextInt(MAX_PROVEEDORES-MIN_PROVEEEDORES);
        ejecucion=Executors.newFixedThreadPool(numProv);
        
        for (int i = 0; i < numProv; i++) {
            arrayProveedores.add(new Proveedor(generaId()));
        }
    }
    
    public static String generaId(){
        ID+="1";
        return ID;
    }
    
}

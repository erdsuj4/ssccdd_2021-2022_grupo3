/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es.uja.ssccdd.curso2122.sesion4;

import static es.uja.ssccdd.curso2122.sesion4.Constantes.MAX_COMPONENTES;
import static es.uja.ssccdd.curso2122.sesion4.Constantes.MIN_COMPONENTES;
import static es.uja.ssccdd.curso2122.sesion4.Constantes.TIEMPO_MAX;
import static es.uja.ssccdd.curso2122.sesion4.Constantes.TIEMPO_MIN;
import es.uja.ssccdd.curso2122.sesion4.Constantes.TipoComponente;
import static es.uja.ssccdd.curso2122.sesion4.Constantes.TipoComponente.getTipoComponente;
import static es.uja.ssccdd.curso2122.sesion4.Constantes.aleatorio;
import static es.uja.ssccdd.curso2122.sesion4.Sesion4.generaId;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.TimeUnit;

/**
 *
 * @author pedroj
 */
public class Fabricante implements Callable<List<Componente>> {

    public Fabricante(String nombre, TipoComponente tipo) {
        this.nombre = nombre;
        this.tipo = tipo;
    }

    public TipoComponente getTipo() {
        return tipo;
    }

    private final String nombre;
    private TipoComponente tipo;

    @Override
    public List<Componente> call() throws Exception {
        int numComponentes = MIN_COMPONENTES + aleatorio.nextInt(MAX_COMPONENTES - MIN_COMPONENTES);
        List<Componente> arrayComponentes = new LinkedList();
        int tiempo;
        try {
            for (int i = 0; i < numComponentes; i++) {
                arrayComponentes.add(new Componente(generaId(),tipo));
                tiempo = TIEMPO_MIN + aleatorio.nextInt(TIEMPO_MAX - TIEMPO_MIN);
                TimeUnit.SECONDS.sleep(tiempo);
            }

        } catch (InterruptedException ex) {
            System.out.println("Fabricante "+nombre+" cancela la fabricacion");
        }

        return arrayComponentes;
    }
}

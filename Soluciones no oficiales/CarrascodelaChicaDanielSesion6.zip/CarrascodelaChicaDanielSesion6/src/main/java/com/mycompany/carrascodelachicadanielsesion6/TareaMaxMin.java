/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.carrascodelachicadanielsesion6;

import static com.mycompany.carrascodelachicadanielsesion6.Constantes.UMBRAL;
import java.util.concurrent.RecursiveAction;

/**
 *
 * @author admin
 */
public class TareaMaxMin extends RecursiveAction {

    public TareaMaxMin(int[] vNumeros, int indiceInicial, int indiceFinal, Resultado resultado) {
        this.vNumeros = vNumeros;
        this.indiceInicial = indiceInicial;
        this.indiceFinal = indiceFinal;
        this.resultado=resultado;
    }

    
    private final int[] vNumeros;
    private final int indiceInicial;
    private final int indiceFinal;
    Resultado resultado;

    
    @Override
    protected void compute(){
        
        if(indiceFinal-indiceInicial > UMBRAL){
            int mitad=(indiceInicial+indiceFinal)/2;
            TareaMaxMin tarea1 = new TareaMaxMin(vNumeros, indiceInicial,mitad,resultado);
            TareaMaxMin tarea2 = new TareaMaxMin(vNumeros, mitad,indiceFinal,resultado);
            invokeAll(tarea1,tarea2);            
            
        }else{
            for(int i=indiceInicial;i<indiceFinal;i++){
                if(vNumeros[i]>resultado.getMaximo()){
                    resultado.setMaximo(vNumeros[i]);
                    resultado.setPosMaximo(i);
                }
                if(vNumeros[i]<resultado.getMinimo()){
                    resultado.setMinimo(vNumeros[i]);
                    resultado.setPosMinimo(i);
                }
            }
        }
    }
    
}

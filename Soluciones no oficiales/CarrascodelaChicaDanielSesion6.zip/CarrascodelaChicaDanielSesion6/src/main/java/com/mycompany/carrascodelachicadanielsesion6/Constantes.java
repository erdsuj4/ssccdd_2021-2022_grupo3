/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.carrascodelachicadanielsesion6;

import java.util.Random;

/**
 *
 * @author admin
 */
public interface Constantes {
    public static final Random aleatorio = new Random();
    public static final int N_DATOS = 80; //NUMERO DE DATOS DEL VECTOR
    public static final int INF = 99999;
    public static final int MENOS_INF = -9999;
    public static final int INICIO = 0;
    public static final int MINIMO = 1; //MINIMO VALOR QUE SE PUEDE ENCONTRAR EN EL VECTOR
    public static final int MAXIMO = 90; //MAXIMO VALOR QUE SE PUEDE ENCONTRAR EN EL VECTOR
    public static final int UMBRAL = 8;
    public static final int TIEMPO_ESPERA=1;
}

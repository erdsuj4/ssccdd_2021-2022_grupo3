/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.carrascodelachicadanielsesion6;

import static com.mycompany.carrascodelachicadanielsesion6.Constantes.INF;
import static com.mycompany.carrascodelachicadanielsesion6.Constantes.MENOS_INF;

/**
 *
 * @author admin
 */
public class Resultado {

    private int posMinimo;
    private int minimo;
    private int posMaximo;
    private int maximo;

    @Override
    public String toString() {
        return "Resultado{" + "posMinimo=" + posMinimo + ", minimo=" + minimo + ", posMaximo=" + posMaximo + ", maximo=" + maximo + '}';
    }

    public void setPosMinimo(int posMinimo) {
        this.posMinimo = posMinimo;
    }

    public void setMinimo(int minimo) {
        this.minimo = minimo;
    }

    public void setPosMaximo(int posMaximo) {
        this.posMaximo = posMaximo;
    }

    public void setMaximo(int maximo) {
        this.maximo = maximo;
    }

    public int getPosMinimo() {
        return posMinimo;
    }

    public int getMinimo() {
        return minimo;
    }

    public int getPosMaximo() {
        return posMaximo;
    }

    public int getMaximo() {
        return maximo;
    }

    public Resultado(int posMinimo, int minimo, int posMaximo, int maximo) {
        this.posMinimo = posMinimo;
        this.minimo = minimo;
        this.posMaximo = posMaximo;
        this.maximo = maximo;
    }

    public Resultado() {
        this.posMinimo = 0;
        this.minimo = INF;
        this.posMaximo = 0;
        this.maximo = MENOS_INF;
    }

}

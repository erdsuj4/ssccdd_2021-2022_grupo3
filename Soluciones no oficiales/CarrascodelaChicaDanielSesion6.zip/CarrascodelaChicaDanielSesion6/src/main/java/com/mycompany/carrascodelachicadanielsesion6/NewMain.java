/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.carrascodelachicadanielsesion6;

import static com.mycompany.carrascodelachicadanielsesion6.Constantes.INICIO;
import static com.mycompany.carrascodelachicadanielsesion6.Constantes.MAXIMO;
import static com.mycompany.carrascodelachicadanielsesion6.Constantes.MINIMO;
import static com.mycompany.carrascodelachicadanielsesion6.Constantes.N_DATOS;
import static com.mycompany.carrascodelachicadanielsesion6.Constantes.TIEMPO_ESPERA;
import static com.mycompany.carrascodelachicadanielsesion6.Constantes.aleatorio;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.TimeUnit;

/**
 *
 * @author admin
 */
public class NewMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("EMPIEZA EJECUCION HILO PRINCIPAL");
        
        int[] datos = new int[N_DATOS];
        //relleno el vector de datos
        for (int i=0; i < datos.length; i++) {
            datos[i] = MINIMO+aleatorio.nextInt(MAXIMO);
        }
        
        Resultado res;
        res=new Resultado();
        
        //Ejecuto la TareaMaxMin
        TareaMaxMin tarea=new TareaMaxMin(datos,INICIO,datos.length,res);
        
        ForkJoinPool pool = new ForkJoinPool();
        pool.execute(tarea);
        
        //espero a que finalice la tarea
        pool.awaitQuiescence(TIEMPO_ESPERA, TimeUnit.DAYS);
        
        //imprimo el vector
        for(int i=0;i<N_DATOS;i++){
            System.out.print(datos[i]+" ");
        }
        System.out.println("");
        
        //muestro el resultado
        System.out.println(res);

        System.out.println("EL HILO PRINCIPAL FINALIZA SU EJECUCION");
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es.uja.ssccdd.curso2122.sesion5;

import static es.uja.ssccdd.curso2122.sesion5.Constantes.ESPERA_MAX_ORDENADOR;
import static es.uja.ssccdd.curso2122.sesion5.Constantes.ESPERA_MIN_ORDENADOR;
import static es.uja.ssccdd.curso2122.sesion5.Constantes.aleatorio;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.TimeUnit;

/**
 *
 * @author pedroj
 */
public class FabricanteOrdenador implements Callable<Ordenador> {

    public FabricanteOrdenador(String nombre) {
        this.nombre = nombre;
    }
    private final String nombre;

    @Override
    public Ordenador call() throws Exception {
        Ordenador ordena = null;
        try {
            ordena = crearOrdenador();
        } catch (InterruptedException ex) {
            System.out.println("TAREA-" + nombre + " se ha CANCELADO");
        }
        return ordena;
    }

    private Ordenador crearOrdenador() throws InterruptedException {
        if (Thread.currentThread().isInterrupted()) {
            throw new InterruptedException();
        }

        int espera = ESPERA_MIN_ORDENADOR + aleatorio.nextInt(ESPERA_MAX_ORDENADOR - ESPERA_MIN_ORDENADOR);

        Ordenador ord=new Ordenador(nombre);
        
        TimeUnit.SECONDS.sleep(espera);
        
        return ord;
    }
    
    

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es.uja.ssccdd.curso2122.sesion5;

import static es.uja.ssccdd.curso2122.sesion5.Constantes.ESPERA;
import static es.uja.ssccdd.curso2122.sesion5.Constantes.MAX_COMPONENTES;
import static es.uja.ssccdd.curso2122.sesion5.Constantes.MIN_COMPONENTES;
import static es.uja.ssccdd.curso2122.sesion5.Constantes.TipoComponente.getTipoComponente;
import static es.uja.ssccdd.curso2122.sesion5.Constantes.aleatorio;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletionService;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

/**
 *
 * @author pedroj
 */
public class FabricanteComponentes implements Callable<List<Componente>> {

    public FabricanteComponentes(String nombre) {
        this.nombre = nombre;
        this.listaTareas =new ArrayList();
    }
    private final String nombre;
    private final List<Componente> listaTareas;
    
    @Override
    public List<Componente> call() throws Exception {
        try{
            crearComponentes();
        }catch(InterruptedException ex){
            System.out.println("TAREA-" + nombre + " se ha CANCELADO");
        }
        return listaTareas;
    }
    
    private void crearComponentes() throws InterruptedException{
        
        if(Thread.currentThread().isInterrupted()){
            throw new InterruptedException();
        }
        
        int numComp=MIN_COMPONENTES+aleatorio.nextInt(MAX_COMPONENTES-MIN_COMPONENTES);
        
        for(int i=0;i<numComp;i++){
            listaTareas.add(new Componente(nombre, getTipoComponente()));
            TimeUnit.SECONDS.sleep(ESPERA);
        }
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es.uja.ssccdd.curso2122.sesion5;

import static es.uja.ssccdd.curso2122.sesion5.Constantes.ESPERA_FINALIZACION;
import java.util.ArrayList;
import java.util.concurrent.CompletionService;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;

/**
 *
 * @author UJA
 */
public class Sesion5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        ScheduledExecutorService ejecucionSistema;
        CompletionService<FabricanteOrdenador> nuevoFab;
        CompletionService<FabricanteComponentes> nuevoComp;
        ExecutorService ejecucion;
        ArrayList<Future<Resultado>> listaTareasProveedores;
        CountDownLatch esperaFinalizacion;
        
        listaTareasProveedores=new ArrayList();
        esperaFinalizacion = new CountDownLatch(ESPERA_FINALIZACION);
        
    }

}

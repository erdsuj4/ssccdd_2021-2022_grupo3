/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es.uja.ssccdd.curso2122.sesion5;

import static es.uja.ssccdd.curso2122.sesion5.Constantes.TipoComponente.getTipoComponente;
import java.util.List;
import java.util.concurrent.CompletionService;
import java.util.concurrent.Future;

/**
 *
 * @author pedroj
 */
public class GeneradorTareas implements Runnable {

    public GeneradorTareas(String nombre, CompletionService<Ordenador> nuevoOrdenador, CompletionService<List<Componente>> nuevoComponente, List<Future<?>> listaTarea) {
        this.nombre = nombre;
        this.nuevoOrdenador = nuevoOrdenador;
        this.nuevoComponente = nuevoComponente;
        this.listaTarea = listaTarea;
        this.numEjecuciones=0;
    }
   
    private final String nombre;
    private final CompletionService<Ordenador> nuevoOrdenador;
    private final CompletionService<List<Componente>> nuevoComponente;
    private final List<Future<?>> listaTarea;
    private int numEjecuciones;
    
    @Override
    public void run() {
        try{
            if(numEjecuciones%2==0){
                crearComponente();
            }else{
                crearOrdenador();
            }
            numEjecuciones++;
        }catch (InterruptedException ex) {
            System.out.println("TAREA-" + nombre + " se ha CANCELADO");
        }

    }
    
    private void crearComponente() throws InterruptedException{
        Future<List<Componente>> comp;
       if( Thread.currentThread().isInterrupted() )
            throw new InterruptedException();
       
       FabricanteComponentes crearComp=new FabricanteComponentes(nombre);
       comp=nuevoComponente.submit(crearComp);
       
       listaTarea.add(comp);
       
    }
    
    private void crearOrdenador() throws InterruptedException{
        Future<Ordenador> ord;
       if( Thread.currentThread().isInterrupted() )
            throw new InterruptedException();
       
       FabricanteOrdenador crearOrd=new FabricanteOrdenador(nombre);
       ord=nuevoOrdenador.submit(crearOrd);
       
       listaTarea.add(ord);
       
    }
    
}

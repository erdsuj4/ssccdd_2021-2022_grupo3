/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es.uja.ssccdd.curso2122.sesion5;

import static es.uja.ssccdd.curso2122.sesion5.Constantes.ESPERA;
import static es.uja.ssccdd.curso2122.sesion5.Constantes.FINAL;
import static es.uja.ssccdd.curso2122.sesion5.Constantes.MAX_ORDENADORES;
import static es.uja.ssccdd.curso2122.sesion5.Constantes.MIN_ORDENADORES;
import static es.uja.ssccdd.curso2122.sesion5.Constantes.aleatorio;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletionService;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

/**
 *
 * @author pedroj
 */
public class Proveedor implements Callable<Resultado> {

    public Proveedor(String nombre, CompletionService<Ordenador> nuevoOrdenador, CompletionService<List<Componente>> nuevoComponente) {
        this.nombre = nombre;
        this.nuevoOrdenador = nuevoOrdenador;
        this.nuevoComponente = nuevoComponente;
        this.arrayOrd = new ArrayList();
        this.arrayComponentes = new ArrayList();

        this.numOrdenadores = MIN_ORDENADORES + aleatorio.nextInt(MAX_ORDENADORES - MIN_ORDENADORES);
        this.ordenadoresCompletados = (numOrdenadores * 50) / 100;
        this.comp = new ArrayList();
        this.ultimoOrdenador = 0;
        this.cojoComp=null;
    }

    private final String nombre;
    private final CompletionService<Ordenador> nuevoOrdenador;
    private final CompletionService<List<Componente>> nuevoComponente;
    private final List<Ordenador> arrayOrd;
    private final List<Componente> arrayComponentes;//los no asignados
    private int ordenadoresCompletados;
    private int numOrdenadores;
    private List<Componente> comp;
    private int ultimoOrdenador;
    private Componente cojoComp;

    @Override
    public Resultado call() throws Exception {
        Resultado res = null;
        inicializaOrdenador();
        System.out.println("LA TAREA(" + nombre + ") comienza la preparación de " +
                           ordenadoresCompletados + " ordenadores completos");

        try {
            while (ordenadoresCompletados != FINAL) {
                asignarComponentes();
            }
            System.out.println("Ha finalizado la ejecución del TAREA-" + nombre);
        } catch (InterruptedException | ExecutionException ex) {
            System.out.println("TAREA-" + nombre + " ha sido CANCELADA " + ex);
        }finally{
            finalizacion(res);
        }
        return res;
    }

    private void inicializaOrdenador() {
        for (int i = 0; i < numOrdenadores; i++) {
            Ordenador ordena = new Ordenador(nombre);
            arrayOrd.add(ordena);
        }
    }

    private void asignarComponentes() throws InterruptedException, ExecutionException {
        if (Thread.interrupted()) {
            throw new InterruptedException();
        }
        cojoComp = null;

        Future<List<Componente>> componentesCreados;
        componentesCreados = nuevoComponente.take();
        comp = componentesCreados.get();

        int ordenadoresRev = 0;
        boolean asignado=false;
        while ((ordenadoresRev < arrayOrd.size()) && !asignado) {
            asignado = false;
            int indice = (ultimoOrdenador + ordenadoresRev) % arrayOrd.size();
            for (int j = 0; j < comp.size() && !arrayOrd.get(indice).isCompleto(); j++) {
                if (arrayOrd.get(indice).addComponente(comp.get(j))) {
                    asignado = true;
                    cojoComp=comp.get(j);
                    comp.remove(comp.get(j));
                    if (comp.isEmpty()) {
                        comp = null;
                    }
                    
                    TimeUnit.SECONDS.sleep(ESPERA);
                } else {
                    ordenadoresRev++;
                }
            }

            if (asignado) {
                ultimoOrdenador = (ultimoOrdenador + ordenadoresRev + 1) % arrayOrd.size();
            } else {
                arrayComponentes.add(cojoComp);
            }
        }
    }
    
    private void finalizacion(Resultado res){
        if(cojoComp!=null){
            arrayComponentes.add(cojoComp);
        }
        
        res=new Resultado(nombre, arrayOrd, arrayComponentes);
    }

}

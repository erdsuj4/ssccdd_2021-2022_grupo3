/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package es.uja.ssccdd.curso2122.sesion1;

import static es.uja.ssccdd.curso2122.sesion1.Constantes.LLENO;
import static es.uja.ssccdd.curso2122.sesion1.Constantes.TIPO_COMPONENTES;
import es.uja.ssccdd.curso2122.sesion1.Constantes.TipoComponente;
import static es.uja.ssccdd.curso2122.sesion1.Constantes.componentes;
import java.util.ArrayList;

/**
 *
 * @author admin
 */
public class Ordenador {

    @Override
    public String toString() {
        String texto= "Ordenador{" + "id=" + id + '}'+"\n";
        for(int i=0;i<componentes.length;i++){
            texto+=TipoComponente.values()[i]+ " --> ";
            for(int j=0;j<memoria[i].length;j++){
                texto+=memoria[i][j]+" ";
            }
            texto+="\n";
        }
        return texto;
    }

    public Ordenador(int id, Componente[][] memoria) {
        this.id = id;
        this.memoria = memoria;
    }

    public Ordenador(int id, int[] capacidad, boolean nosimple) {
        this.id = id;
        if (nosimple) {
            for (int i = 0; i < TIPO_COMPONENTES; i++) {
                capacidad[i] = 2 * capacidad[i];
            }
        }

        this.memoria = new Componente[componentes.length][];
        for (int i = 0; i < componentes.length; i++) {
            memoria[i] = new Componente[capacidad[i]];
        }
    }

    public int addComponente(Componente nuevoComponente) {
        int tipo = nuevoComponente.getTipo().ordinal();
        boolean asignado = false;
        int capacidad = memoria[tipo].length;

        for (int i = 0; i < memoria[tipo].length && !asignado; i++) {
            if (memoria[tipo][i] == null) {
                memoria[tipo][i] = nuevoComponente;
                capacidad-=i+1;
                asignado = true;
            }
        }
        if (!asignado) {
            return LLENO;//si devuelve -1 se ha ocupado la capacidad maxima
        }
        return capacidad;//si devuelve la capacidad restante es porque se ha añadido co0rrectamente
    }

    private final int id;
    private final Componente memoria[][];
}

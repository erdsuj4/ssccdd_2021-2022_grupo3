/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package es.uja.ssccdd.curso2122.sesion1;

import es.uja.ssccdd.curso2122.sesion1.Constantes.TipoComponente;

/**
 *
 * @author admin
 */
public class Componente {

    public TipoComponente getTipo() {
        return tipo;
    }

    public void setTipo(TipoComponente tipo) {
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        return "Componente{" + "id=" + id + ", tipo=" + tipo + '}';
    }

    public Componente(int id, TipoComponente tipo) {
        this.id = id;
        this.tipo = tipo;
    }
    private final int id;
    TipoComponente tipo;
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es.uja.ssccdd.curso2122.sesion12;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

/**
 *
 * @author UJA
 */
public class Sesion12 implements Constantes{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws InterruptedException {
        // TODO code application logic here
        ExecutorService ejecucion;
        List<Future<?>> listaTareas;
        Future<?> tarea;
        int numProveedores;
        ArrayList<Resultado> arrayresultados;

        // Ejecución del hilo principal
        System.out.println("Ha iniciado la ejecución el Hilo(PRINCIPAL)");

        // Inicialización de las variables para la prueba
        ejecucion = Executors.newCachedThreadPool();
        listaTareas = new ArrayList();
        numProveedores=MIN_PROVEEDORES+aleatorio.nextInt(MAX_PROVEEDORES-MIN_PROVEEDORES);
        arrayresultados=new ArrayList();
        
        // Se crean y se ejecutan las tareas que fabrican los componentes 
        for (int i = 0; i < componentes.length; i++) {
            Fabricante fabricante;
            fabricante = new Fabricante(componentes[i].name(), componentes[i]);
            tarea = ejecucion.submit(fabricante);
            listaTareas.add(tarea);
            TimeUnit.SECONDS.sleep(ESPERA_FABRICANTE);
        }

        // Se crean y se ejecutan las tareas proveedores para que realicen su pedido
        
        for (int i = 0; i < numProveedores; i++) {
            Proveedor proveedor;
            Resultado res=new Resultado();
            proveedor = new Proveedor("Proveedor-" + i,res);
            arrayresultados.add(res);
            tarea = ejecucion.submit(proveedor);
            listaTareas.add(tarea);
        }

        // Esperamos por un tiempo
        System.out.println("HILO(Principal) SUSPENDIDO POR UN TIEMPO");
        

        // Se solicita la cancelación de los pedidos que han excedido el tiempo
        System.out.println("HILO(Principal) Solicita la finalización de los pedidos");
        for (Future<?> task : listaTareas) {
            task.cancel(true);
        }
        for (Resultado arrayresultado : arrayresultados) {
            System.out.println(arrayresultado);
        }

        // Finalizamos el ejecutor y esperamos a que todas las tareas finalicen
        System.out.println("HILO(Principal) Espera a la finalización de las tareas");
        ejecucion.shutdown();
        ejecucion.awaitTermination(TIEMPO_ESPERA, TimeUnit.DAYS);

        // Finalización del hilo principal
        System.out.println("Ha finalizado la ejecución el Hilo(PRINCIPAL)");

    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es.uja.ssccdd.curso2122.sesion12;

import java.util.ArrayList;
import java.util.List;
import javax.jms.Connection;
import javax.jms.Destination;
import javax.jms.MessageConsumer;
import javax.jms.Session;
import org.apache.activemq.ActiveMQConnectionFactory;

/**
 *
 * @author pedroj
 */
public class Proveedor implements Runnable,Constantes {

    private final String iD;
    private final ArrayList<Ordenador> pedido;
    private ActiveMQConnectionFactory connectionFactory;
    private Connection connection;
    private Session session;
    private Destination destination;
    private Resultado res;
    private int numOrdenadores;
    private final ArrayList<Componente> descartados; 
   

    public Proveedor(String iD,Resultado resultado) {
        this.iD = iD;
        this.pedido = new ArrayList();
        this.res=resultado;
        this.numOrdenadores=MIN_ORDENADORES+aleatorio.nextInt(MAX_ORDENADORES-MIN_ORDENADORES);
        this.descartados=new ArrayList();
    }

    @Override
    public void run() {
        System.out.println("TAREA-" + iD + " Comienza con su pedido...");
        
        try {
            inicio();
            for(int i=0;i<numOrdenadores;i++){
                prepararPedido();
            }
        } catch (Exception e) {
            System.out.println("TAREA-" + iD + 
                               " Hay una INCIDENCIA en la confección del pedido: " + e.getMessage());
        } finally {
            fin();
            presentarPedido();
            System.out.println("TAREA-" + iD + " Finaliza su ejecución...");
        }   

    }
    
     public String getiD() {
        return iD;
    }
    
    private void inicio() throws Exception {
        connectionFactory = new ActiveMQConnectionFactory(BROKER_URL);
        connection = connectionFactory.createConnection();
        connection.start();
        session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
        destination = session.createQueue(QUEUE);
        
        for(int i=0;i<numOrdenadores;i++){
            pedido.add(new Ordenador("Id: "+i+iD));
        }
    }
    
    private void prepararPedido() throws Exception {
        if(Thread.interrupted()){
            throw new InterruptedException();
        }
        MessageConsumer consumer = session.createConsumer(destination);
        
        consumer.setMessageListener(new ComponenteListener(iD, pedido,descartados));
        
        
        
        consumer.close();
    }
    
    private void fin() {
        try {
            if (connection != null) {
                connection.close();
            }
        } catch (Exception ex) {
            // No hacer nada
        }
    }
    
    private void presentarPedido() {
        res.setPedidos(pedido);
        res.setDescartados(descartados);
    }


}

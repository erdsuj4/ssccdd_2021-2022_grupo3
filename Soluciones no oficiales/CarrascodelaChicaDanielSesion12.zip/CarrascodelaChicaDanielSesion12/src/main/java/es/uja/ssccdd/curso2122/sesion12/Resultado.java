/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es.uja.ssccdd.curso2122.sesion12;

import java.util.ArrayList;

/**
 *
 * @author pedroj
 */
public class Resultado {

    private ArrayList<Ordenador> pedidos;
    private ArrayList<Componente> descartados;

    public Resultado() {
        this.pedidos = new ArrayList();
        this.descartados = new ArrayList();
    }

    public void setPedidos(ArrayList<Ordenador> pedidos) {
        this.pedidos = pedidos;
    }

    public void setDescartados(ArrayList<Componente> descartados) {
        this.descartados = descartados;
    }

    @Override
    public String toString() {
        return "Resultado{" + "pedidos=" + pedidos + ", descartados=" + descartados + '}';
    }

}

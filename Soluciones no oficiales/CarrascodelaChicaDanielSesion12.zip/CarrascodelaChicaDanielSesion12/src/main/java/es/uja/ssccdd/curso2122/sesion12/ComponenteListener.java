/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package es.uja.ssccdd.curso2122.sesion12;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

/**
 *
 * @author admin
 */
public class ComponenteListener implements MessageListener {

    private final String consumerName;
    private final List<Ordenador> pedido;
    private final ArrayList<Componente> descartados; 

    public ComponenteListener(String consumerName, List<Ordenador> pedido, ArrayList<Componente> descartados) {
        this.consumerName = consumerName;
        this.pedido = pedido;
        this.descartados=descartados;
    }

    @Override
    public void onMessage(Message msg) {
        GsonUtil<Componente> gsonUtil = new GsonUtil();

        try {
            if (msg instanceof TextMessage) {
                TextMessage contenido = (TextMessage) msg;
                Componente componente = gsonUtil.decode(contenido.getText(), Componente.class);
                System.out.println(consumerName + " processing job: " + componente);
                addComponente(componente);
            } else {
                System.out.println(consumerName + " Unknown message");
            }
        } catch (JMSException | InterruptedException ex) {
            Logger.getLogger(ComponenteListener.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void addComponente(Componente componente) throws InterruptedException {
        Ordenador ordenador;
        Iterator it = pedido.iterator();
        boolean asignado = false;

        // Asigna componente a un ordenador si es posible
        while (it.hasNext() && !asignado) {
            ordenador = (Ordenador) it.next();
            asignado = ordenador.addComponente(componente);

            // Simulamos el tiempo de montaje si el ordenador está completo
            if (ordenador.isCompleto()) {
                System.out.println(consumerName + " ha completado el ordenador " + ordenador);
            }
        }
        

        // Si no se ha podido asignar el componente se crea un nuevo ordenador
        // al pedido y se le asigna el componente
        if (!asignado) {
            descartados.add(componente);
        }
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es.uja.ssccdd.curso2122.sesion8;

import static es.uja.ssccdd.curso2122.sesion8.Constantes.ASIGNADO;
import static es.uja.ssccdd.curso2122.sesion8.Constantes.FINAL_PEDIDO;
import static es.uja.ssccdd.curso2122.sesion8.Constantes.MAXIMO;
import static es.uja.ssccdd.curso2122.sesion8.Constantes.MIN_ORDENADORES;
import static es.uja.ssccdd.curso2122.sesion8.Constantes.OBJETIVO_CONSTRUCCION;
import es.uja.ssccdd.curso2122.sesion8.Constantes.TipoComponente;
import static es.uja.ssccdd.curso2122.sesion8.Constantes.VARIACION_ORDENADORES;
import static es.uja.ssccdd.curso2122.sesion8.Constantes.aleatorio;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.BlockingDeque;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

/**
 *
 * @author pedroj
 */
public class Proveedor implements Callable<Resultado> {

    public Proveedor(String nombre, BlockingDeque<Componente> arrayComponentes,BlockingDeque<Ordenador> ordcomp) {
        this.nombre = nombre;
        this.arrayComponentes = arrayComponentes;
        this.arrayOrdenadoresCompartidos = ordcomp;
        this.numOrdenadores = MIN_ORDENADORES + aleatorio.nextInt(VARIACION_ORDENADORES);
        this.ordenadoresCompletados = (numOrdenadores * OBJETIVO_CONSTRUCCION) / 100;
        this.noAsignado = new ArrayList();
        this.arrayOrdenadores=new ArrayList();
    }
    private final String nombre;
    private final BlockingDeque<Componente> arrayComponentes;
    private final ArrayList<Ordenador> arrayOrdenadores;
       private final BlockingDeque<Ordenador> arrayOrdenadoresCompartidos;
    private final ArrayList<Componente> noAsignado;
    private int numOrdenadores;
    private int ordenadoresCompletados;

    @Override
    public Resultado call() throws Exception {
        Resultado resultado = null;

        System.out.println("LA TAREA(" + nombre + ") comienza la preparación de "
                + ordenadoresCompletados + " ordenadores completos");

        try {
            crearOrdenadores();

            // Hasta su finalización o su interrupción
            while (ordenadoresCompletados != FINAL_PEDIDO) {
                System.out.println("LA TAREA(" + nombre + ") espera nuevos componentes");
                asignarComponentes();
            }

            System.out.println("FINALIZADO ejecucion tarea " + nombre);
        } catch (InterruptedException ex) {
            System.out.println("LA TAREA(" + nombre + ") ha sido INTERRUMPIDO");
        } finally {
            // finalizamos los gestores activos y el marco de ejecución
            finalizacion(resultado);
            System.out.println("TAREA "+nombre+ " HA TERMINADO");
        }

        return resultado;

    }

    private void crearOrdenadores() throws InterruptedException {
        for (int i = 0; i < numOrdenadores; i++) {
            Ordenador ordenador = arrayOrdenadoresCompartidos.take();
            arrayOrdenadores.add(ordenador);
        }
    }

    private void asignarComponentes() throws InterruptedException {
        if (Thread.interrupted()) {
            throw new InterruptedException();
        }
        Componente comp = arrayComponentes.take();
        System.out.println("Proveedor " + nombre + " asignando " + comp);

        boolean asignado = false;
        int indice = 0;
        while ((indice < arrayOrdenadores.size()) && !asignado) {
            if (arrayOrdenadores.get(indice).addComponente(comp) != !ASIGNADO) {
                asignado = true;
                if (arrayOrdenadores.get(indice).isCompleto()) {
                    ordenadoresCompletados--;
                }
                System.out.println("LA TAREA(" + nombre + ") ha asignado " + comp
                        + " al ordenador " + arrayOrdenadores.get(indice).getID()
                        + " ordenadores pendientes " + ordenadoresCompletados);

            } else {
                indice++;
            }
        }

        if (!asignado) {
            arrayOrdenadores.add(new Ordenador(nombre));
            noAsignado.add(comp);
        }

        // Simulamos por último el tiempo de asignación porque si se interrumpe
        // ya hemos completado la operación de asignación
        TimeUnit.SECONDS.sleep(tiempoAsignacion(comp.getTipo()));

    }

    private void finalizacion(Resultado res) {
        res = new Resultado(nombre, arrayOrdenadores, noAsignado);
    }

    private int tiempoAsignacion(TipoComponente tipoArchivo) {
        return MAXIMO + tipoArchivo.ordinal();
    }

}

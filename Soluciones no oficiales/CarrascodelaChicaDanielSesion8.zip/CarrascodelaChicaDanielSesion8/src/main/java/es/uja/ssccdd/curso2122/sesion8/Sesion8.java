/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es.uja.ssccdd.curso2122.sesion8;

import static es.uja.ssccdd.curso2122.sesion8.Constantes.MIN_PROVEEDORES;
import static es.uja.ssccdd.curso2122.sesion8.Constantes.VARIACION_PROVEEDORES;
import static es.uja.ssccdd.curso2122.sesion8.Constantes.aleatorio;
import java.util.ArrayList;
import java.util.concurrent.DelayQueue;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.ScheduledExecutorService;


/**
 *
 * @author UJA
 */
public class Sesion8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws InterruptedException, ExecutionException {
        // TODO code application logic here
        ExecutorService ejecucion = Executors.newCachedThreadPool();
        Resultado res;
        LinkedBlockingDeque<Ordenador> listaOrdenadores=new LinkedBlockingDeque();
        ArrayList<Proveedor> listaProveedores=new ArrayList();
        LinkedBlockingDeque<Componente> listaComponente=new LinkedBlockingDeque();
        ArrayList<Fabricante> arrayFabricantes=new ArrayList();
        // Ejecución del hilo principal
        System.out.println("Ha iniciado la ejecución el Hilo(PRINCIPAL)");

        
        // Inicializamos las variables del sistema
        
        int numProveedores = MIN_PROVEEDORES + aleatorio.nextInt(VARIACION_PROVEEDORES);
        for(int i = 0; i < numProveedores; i++) {
            listaProveedores.add(new Proveedor("Provee "+i,listaComponente,listaOrdenadores));
        }
        
        int numFabricante=Constantes.MIN_FABRICANTE+aleatorio.nextInt(Constantes.MAX_FABRICANTE-Constantes.MIN_FABRICANTE);
        for(int i = 0; i <numFabricante ; i++) {
            Fabricante fab=new Fabricante("Fab "+i, listaComponente);
            arrayFabricantes.add(fab);
            ejecucion.execute(fab);
        }
        
        int numOrdenadores=Constantes.MIN_ORDENADORES+aleatorio.nextInt(Constantes.MAX_ORDENADORES-Constantes.MIN_ORDENADORES);

        for(int i=0;i<numOrdenadores;i++){
            listaOrdenadores.add(new Ordenador("id: "+i));
        }
        res = ejecucion.invokeAny(listaProveedores);
        
        ejecucion.shutdownNow();
        ejecucion.awaitTermination(Constantes.TIEMPO_ESPERA, TimeUnit.DAYS);
        System.out.println(res);

        

        

    }

}

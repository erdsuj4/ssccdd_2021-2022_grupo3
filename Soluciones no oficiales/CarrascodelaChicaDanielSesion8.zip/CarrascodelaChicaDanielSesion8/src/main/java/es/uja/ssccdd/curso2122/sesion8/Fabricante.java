/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es.uja.ssccdd.curso2122.sesion8;


import static es.uja.ssccdd.curso2122.sesion8.Constantes.MAXIMO;
import static es.uja.ssccdd.curso2122.sesion8.Constantes.MINIMO;
import static es.uja.ssccdd.curso2122.sesion8.Constantes.TipoComponente.getTipoComponente;
import static es.uja.ssccdd.curso2122.sesion8.Constantes.aleatorio;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;

/**
 *
 * @author pedroj
 */
public class Fabricante implements Runnable {

    public String getNombre() {
        return nombre;
    }

    public Fabricante(String nombre, BlockingQueue<Componente> arrayComponentes) {
        this.nombre = nombre;
        this.arrayComponentes = arrayComponentes;
    }

    private final String nombre;
    private final BlockingQueue<Componente> arrayComponentes;

    
     @Override
    public void run() {
        try {
            
            crearComponente();
            
        } catch (InterruptedException ex) {
            System.out.println("TAREA-" + nombre + " Ha sido CANCELADA " + ex);
        } 
    } 
    
    private void crearComponente() throws InterruptedException {
        if ( Thread.interrupted() )
            throw new InterruptedException();
        
        // Simula la creación de un proceso
        Componente com=new Componente(nombre, getTipoComponente());
        int tiempo = MINIMO + aleatorio.nextInt(MAXIMO - MINIMO);
        System.out.println("TAREA-" + nombre + " Crea " + com);
        TimeUnit.SECONDS.sleep(tiempo);
        
        arrayComponentes.put(com);
    }



    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es.uja.ssccdd.curso2122.sesion11;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

/**
 *
 * @author UJA
 */
public class Sesion11 implements Constantes {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws InterruptedException {
        // TODO code application logic here
        ExecutorService ejecucion;
        List<Future<?>> listaProveedores;
        List<Future<?>> listaFabricantes;
        Future<?> tarea;
        int numProveedor;
        Resultado resultado;

        // Ejecución del hilo principal
        System.out.println("Ha iniciado la ejecución el Hilo(PRINCIPAL)");

        // Inicialización de las variables para la prueba
        ejecucion = Executors.newCachedThreadPool();
        listaFabricantes = new ArrayList();
        listaProveedores = new ArrayList();
        numProveedor = MIN_PROVEEDOR + aleatorio.nextInt(MAX_PROVEEDOR - MIN_PROVEEDOR);
        resultado = new Resultado();

        // Crear y ejecutar los planificadores
        for (int i = 0; i < componentes.length; i++) {
            Fabricante fabricante;
            fabricante = new Fabricante("fab: " + i, componentes[i]);
            tarea = ejecucion.submit(fabricante);
            listaFabricantes.add(tarea);
        }

        // Crear y ejecutar los gestores de procesos
        for (int i = 0; i < numProveedor; i++) {
            Proveedor proveedor;
            proveedor = new Proveedor("Proveedor: " + i);
            tarea = ejecucion.submit(proveedor);
            listaProveedores.add(tarea);
        }

        // Esperamos por un tiempo
        System.out.println("HILO(Principal) SUSPENDIDO POR UN TIEMPO");
       

        // Se solicita la cancelación de los pedidos que han excedido el tiempo
        System.out.println("HILO(Principal) Solicita la finalización de los ordenadores");
       

        // Finalizamos el ejecutor y esperamos a que todas las tareas finalicen
        System.out.println("HILO(Principal) Espera a la finalización de las tareas");
        ejecucion.shutdown();
        ejecucion.awaitTermination(TIEMPO_ESPERA, TimeUnit.DAYS);

        // Finalización del hilo principal
        System.out.println("Ha finalizado la ejecución el Hilo(PRINCIPAL)");
        
        System.out.println(resultado);

    }

}

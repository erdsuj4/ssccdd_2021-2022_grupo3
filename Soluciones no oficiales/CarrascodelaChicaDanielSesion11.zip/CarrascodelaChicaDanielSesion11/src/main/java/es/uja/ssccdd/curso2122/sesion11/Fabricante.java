/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es.uja.ssccdd.curso2122.sesion11;

import static es.uja.ssccdd.curso2122.sesion11.Constantes.BROKER_URL;
import static es.uja.ssccdd.curso2122.sesion11.Constantes.MAX_COMPONENTES;
import static es.uja.ssccdd.curso2122.sesion11.Constantes.MIN_COMPONENTES;
import static es.uja.ssccdd.curso2122.sesion11.Constantes.QUEUE;
import es.uja.ssccdd.curso2122.sesion11.Constantes.TipoComponente;
import static es.uja.ssccdd.curso2122.sesion11.Constantes.aleatorio;
import javax.jms.Connection;
import javax.jms.Destination;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;
import org.apache.activemq.ActiveMQConnectionFactory;

/**
 *
 * @author pedroj
 */
public class Fabricante implements Runnable {

    public Fabricante(String id, TipoComponente tipo) {
        this.id = id;
        this.tipo = tipo;
        this.numComp = MIN_COMPONENTES + aleatorio.nextInt(MAX_COMPONENTES - MIN_COMPONENTES);;
    }

    private String id;
    TipoComponente tipo;
    private ActiveMQConnectionFactory connectionFactory;
    private Connection connection;
    private Session session;
    private Destination destination;
    private int numComp;

    @Override
    public void run() {
        System.out.println("Fabricante-" + id + " Comienza su ejecución...");

        try {
            inicio();

            // Creamos los procesos 
            for (int i = 0; i < numComp; i++) {
                ejecutar();
            }
        } catch (Exception e) {
            System.out.println("Fabricante-" + id
                    + " Hay una INCIDENCIA en la ejecución: " + e.getMessage());
        } finally {
            fin();
            System.out.println("Fabricante-" + id + " Finaliza su ejecución...");
        }

    }

    private void inicio() throws Exception {
        connectionFactory = new ActiveMQConnectionFactory(BROKER_URL);
        connection = connectionFactory.createConnection();
        connection.start();
        session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
        destination = session.createQueue(QUEUE + "." + tipo.name());
    }

    private void ejecutar() throws Exception {
        // Se producen los componentes del ordenador
        if(Thread.interrupted()){
            throw new InterruptedException();
        }
        MessageProducer producer = session.createProducer(destination);
        TextMessage message = session.createTextMessage(tipo.name());

        // Se envía el mensaje
        producer.send(message);
        producer.close();

       
    
        System.out.println("Fabricante-" + id + " ha producido un componente de tipo" + tipo);
    }
    
    private void fin() {
        try {
            if (connection != null) {
                connection.close();
            }
        } catch (Exception ex) {
            // No hacer nada
        }
    }


}

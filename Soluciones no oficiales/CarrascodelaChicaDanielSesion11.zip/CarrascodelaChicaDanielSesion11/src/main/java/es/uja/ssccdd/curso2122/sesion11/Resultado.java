/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es.uja.ssccdd.curso2122.sesion11;

import java.util.ArrayList;

/**
 *
 * @author pedroj
 */
public class Resultado {

    private ArrayList<Ordenador> ordenadores;
    private ArrayList<Componente> componentesNoAsignados;

    public Resultado() {
        this.ordenadores = new ArrayList();
        this.componentesNoAsignados = new ArrayList();
    }

    public void setOrdenadores(ArrayList<Ordenador> ordenadores) {
        this.ordenadores = ordenadores;
    }

    public void setComponentesNoAsignados(ArrayList<Componente> componentesNoAsignados) {
        this.componentesNoAsignados = componentesNoAsignados;
    }

    public ArrayList<Ordenador> getOrdenadores() {
        return ordenadores;
    }

    public ArrayList<Componente> getComponentesNoAsignados() {
        return componentesNoAsignados;
    }

    @Override
    public String toString() {
        return "Resultado{" + "ordenadores=" + ordenadores + ", componentesNoAsignados=" + componentesNoAsignados + '}';
    }

}

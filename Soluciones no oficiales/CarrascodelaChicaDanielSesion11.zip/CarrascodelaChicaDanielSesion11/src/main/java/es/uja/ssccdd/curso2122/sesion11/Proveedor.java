/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es.uja.ssccdd.curso2122.sesion11;

import static es.uja.ssccdd.curso2122.sesion11.Constantes.BROKER_URL;
import static es.uja.ssccdd.curso2122.sesion11.Constantes.MAX_ORDENADORES;
import static es.uja.ssccdd.curso2122.sesion11.Constantes.MIN_ORDENADORES;
import static es.uja.ssccdd.curso2122.sesion11.Constantes.QUEUE;
import es.uja.ssccdd.curso2122.sesion11.Constantes.TipoComponente;
import static es.uja.ssccdd.curso2122.sesion11.Constantes.aleatorio;
import static es.uja.ssccdd.curso2122.sesion11.Constantes.componentes;
import java.util.ArrayList;
import javax.jms.Connection;
import javax.jms.Destination;
import javax.jms.MessageConsumer;
import javax.jms.Session;
import javax.jms.TextMessage;
import org.apache.activemq.ActiveMQConnectionFactory;

/**
 *
 * @author pedroj
 */
public class Proveedor implements Runnable {

    private final String id;
    private final ArrayList<Ordenador> pedido;
    private final ArrayList<Componente> componentesNoAsignados;
    private final ArrayList<TipoComponente> tiposDescartados;
    private ActiveMQConnectionFactory connectionFactory;
    private Connection connection;
    private Session session;
    private Destination[] destination;
    private int numordenadores;
    private int ordenadoresCompletados;
    Resultado resultado;

    public Proveedor(String id) {
        this.id = id;
        this.pedido = new ArrayList();
        this.numordenadores = MIN_ORDENADORES + aleatorio.nextInt(MAX_ORDENADORES - MIN_ORDENADORES);
        this.componentesNoAsignados = new ArrayList();
        this.tiposDescartados = new ArrayList();
        this.resultado = new Resultado();
    }

    @Override
    public void run() {
        System.out.println("Proveedor-" + id + " Comienza con su pedido...");

        try {
            inicio();

            int indice = 0;

            while (indice < numordenadores) {
                prepararPedido(indice);
                if (pedido.get(indice).isCompleto()) {
                    indice++;
                    tiposDescartados.clear();
                }
            }
        } catch (Exception e) {
            System.out.println("TAREA-" + id
                    + " Hay una INCIDENCIA en la confección del pedido: " + e.getMessage());
        } finally {
            fin();
            generarResultado();
            System.out.println("TAREA-" + id + " Finaliza su ejecución...");
        }

    }

    private void inicio() throws Exception {
        connectionFactory = new ActiveMQConnectionFactory(BROKER_URL);
        connection = connectionFactory.createConnection();
        connection.start();
        session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);

        // Tenemos un destino para cada componente
        destination = new Destination[componentes.length];
        for (TipoComponente componente : componentes) {
            destination[componente.ordinal()] = session.createQueue(QUEUE + "." + componente.name());
        }

        for (int i = 0; i < numordenadores; i++) {
            pedido.add(new Ordenador("id: " + i));
        }
    }

    private void prepararPedido(int indice) throws Exception {
        if (Thread.interrupted()) {
            throw new InterruptedException();
        }

        //Ordenador ordenador = new Ordenador("ordenador: "+indice);
        boolean asignado;
        // Obtenemos los componentes del ordenador de forma síncrona
        for (TipoComponente tcomponente : componentes) {
            if (!tiposDescartados.contains(tcomponente)) {
                MessageConsumer consumer = session.createConsumer(destination[tcomponente.ordinal()]);
                TextMessage msg = (TextMessage) consumer.receive();
                consumer.close();

                System.out.println("Ordenador-" + id + " Obtiene el componente: " + msg.getText());
                Componente componente = new Componente("id: " + indice, TipoComponente.valueOf(msg.getText()));
                asignado = pedido.get(indice).addComponente(componente);

                if (!asignado) {
                    componentesNoAsignados.add(componente);
                    tiposDescartados.add(tcomponente);
                }
            }
        }

        // Simulamos el tiempo de construcción de un ordenador para añadirlo al pedido
        System.out.println("Proveedor-" + id + " Finaliza el ordenador: " + indice);

    }

    private void fin() {
        try {
            if (connection != null) {
                connection.close();
            }
        } catch (Exception ex) {
            // No hacer nada
        }
    }

    private void generarResultado() {
        resultado.setComponentesNoAsignados(componentesNoAsignados);
        resultado.setOrdenadores(pedido);
    }

}
